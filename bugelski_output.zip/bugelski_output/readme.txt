Task: Bugelski

GP Parameters: 
	Max Generations: 50
	Population size: 100

Independent runs for different presentation times