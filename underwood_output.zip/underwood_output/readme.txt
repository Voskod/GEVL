Task: Underwood
Data: Dmitry's modified data
GP Parameters: 
	Max Generations: 50
	Population size: 500

Independent runs for all 5 conditions 